require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const session = require('express-session');
const MongoStore = require('connect-mongo');
const cookieParser = require('cookie-parser');
const cors = require('cors');
const morgan = require('morgan');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/sharehub';
const isProd = process.env.NODE_ENV === 'production';

app.set('trust proxy', 1);                       // cần khi chạy sau proxy của Render
app.use(morgan('dev'));
app.use(cors({ origin: process.env.CLIENT_ORIGIN || true, credentials: true }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(session({
  name: 'connect.sid',
  secret: process.env.SESSION_SECRET || 'dev-secret',
  resave: false,
  saveUninitialized: true,                       // cho phép giỏ/đơn nháp của khách chưa đăng nhập
  store: MongoStore.create({ mongoUrl: MONGODB_URI, ttl: 14 * 24 * 3600 }),
  cookie: { httpOnly: true, sameSite: 'lax', secure: isProd },
}));

app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use('/api/auth', require('./routes/auth'));
app.use('/api/users', require('./routes/users'));
app.use('/api/categories', require('./routes/categories'));
app.use('/api/assets', require('./routes/assets'));
app.use('/api/bookings', require('./routes/bookings'));
app.use('/api/chat', require('./routes/chat'));
app.use('/api/requests', require('./routes/requests'));
app.use('/api/lender', require('./routes/lender'));
app.use('/api/admin', require('./routes/admin'));
app.get('/api/health', (req, res) => res.json({ ok: true, db: mongoose.connection.readyState === 1 }));

// Khi đã build Angular → Express phục vụ luôn SPA (deploy 1 link duy nhất)
const dist = path.join(__dirname, '..', 'client', 'dist', 'client', 'browser');
if (fs.existsSync(dist)) {
  app.use(express.static(dist));
  app.get(/^\/(?!api|uploads).*/, (req, res) => res.sendFile(path.join(dist, 'index.html')));
}

app.use((err, req, res, next) => { console.error(err); res.status(500).json({ message: err.message || 'Server error' }); });

mongoose.connect(MONGODB_URI)
  .then(async () => {
    console.log('✅ Connected to MongoDB');
    const { Category } = require('./models');
    if (!(await Category.countDocuments())) await require('./seed').run(false);   // tự seed lần đầu
    app.listen(PORT, () => console.log(`🚀 ShareHub running on http://localhost:${PORT}`));
  })
  .catch(err => { console.error('❌ MongoDB connection error:', err.message); process.exit(1); });
