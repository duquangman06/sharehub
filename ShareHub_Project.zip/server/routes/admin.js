const router = require('express').Router();
const { User, Asset, Category, Booking } = require('../models');
const { requireAuth, requireAdmin } = require('../middleware/auth');
const { slugify, recalcTrust } = require('../utils');
router.use(requireAuth, requireAdmin);

router.get('/stats', async (req, res) => {
  const [users, assets, bookings, pendingAssets, pendingKyc, openDisputes] = await Promise.all([
    User.countDocuments(), Asset.countDocuments({ status: 'active' }), Booking.countDocuments(),
    Asset.countDocuments({ status: 'pending' }), User.countDocuments({ kycStatus: 'pending' }), Booking.countDocuments({ status: 'disputed' })]);
  res.json({ users, assets, bookings, pendingAssets, pendingKyc, openDisputes });
});

// Danh mục
router.post('/categories', async (req, res) => res.status(201).json(await Category.create({ name: req.body.name, slug: slugify(req.body.name), icon: req.body.icon || '📦' })));
router.delete('/categories/:id', async (req, res) => res.json({ deleted: (await Category.deleteOne({ _id: req.params.id })).deletedCount }));

// Kiểm duyệt thiết bị
router.get('/assets', async (req, res) => res.json(await Asset.find({ status: req.query.status || 'pending' }).populate('owner', 'name email')));
router.post('/assets/:id/:action(approve|reject)', async (req, res) => {
  res.json(await Asset.findByIdAndUpdate(req.params.id, { status: req.params.action === 'approve' ? 'active' : 'rejected' }, { new: true }));
});

// Xác minh danh tính
router.get('/kyc', async (req, res) => res.json(await User.find({ kycStatus: 'pending' }, 'name email kycImages kycStatus createdAt')));
router.post('/kyc/:id/:action(approve|reject)', async (req, res) => {
  const u = await User.findByIdAndUpdate(req.params.id, { kycStatus: req.params.action === 'approve' ? 'verified' : 'rejected' }, { new: true });
  await recalcTrust(u._id); res.json({ ok: true });
});

// Dispute Room
router.get('/disputes', async (req, res) => {
  res.json(await Booking.find({ status: 'disputed' }).populate('asset', 'title images').populate('renter owner', 'name email').populate('dispute.openedBy', 'name'));
});
router.post('/disputes/:id/resolve', async (req, res) => {
  const b = await Booking.findById(req.params.id);
  if (!b || b.status !== 'disputed') return res.status(400).json({ message: 'No open dispute.' });
  const pct = Math.min(100, Math.max(0, +req.body.refundToRenterPercent));
  const refund = Math.round(b.deposit * pct / 100), comp = b.deposit - refund;
  await User.updateOne({ _id: b.renter }, { $inc: { walletBalance: refund, completedCount: 1 } });
  await User.updateOne({ _id: b.owner }, { $inc: { walletBalance: (b.rentalFee - b.discount) + comp, completedCount: 1 } });
  b.dispute.status = 'resolved'; b.dispute.refundToRenterPercent = pct; b.dispute.compensationToOwner = comp;
  b.dispute.adminNote = req.body.note; b.dispute.resolvedAt = new Date();
  b.status = 'completed'; b.paymentStatus = pct === 100 ? 'refunded' : 'partial';
  await b.save(); res.json(b);
});
module.exports = router;
