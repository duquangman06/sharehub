const router = require('express').Router();
const { User, Review, Asset } = require('../models');
const { requireAuth } = require('../middleware/auth');
const upload = require('../middleware/upload');
const { selfUser, publicUser } = require('../utils');

router.put('/me', requireAuth, upload.single('avatar'), async (req, res) => {
  const { name, phone, bio } = req.body;
  if (name) req.user.name = name;
  if (phone !== undefined) req.user.phone = phone;
  if (bio !== undefined) req.user.bio = bio;
  if (req.file) req.user.avatar = '/uploads/' + req.file.filename;
  await req.user.save();
  res.json(selfUser(req.user));
});

// eKYC: tải 2 mặt CCCD / hộ chiếu
router.post('/me/kyc', requireAuth, upload.array('docs', 2), async (req, res) => {
  if (!req.files?.length) return res.status(400).json({ message: 'Please upload ID images.' });
  req.user.kycImages = req.files.map(f => '/uploads/' + f.filename);
  req.user.kycStatus = 'pending';
  await req.user.save();
  res.json(selfUser(req.user));
});

router.get('/:id', async (req, res) => {
  const u = await User.findById(req.params.id);
  if (!u) return res.status(404).json({ message: 'User not found.' });
  const reviews = await Review.find({ to: u._id }).sort('-createdAt').limit(10).populate('from', 'name avatar');
  const assets = await Asset.find({ owner: u._id, status: 'active' }).limit(8);
  res.json({ user: publicUser(u), reviews, assets });
});

module.exports = router;
