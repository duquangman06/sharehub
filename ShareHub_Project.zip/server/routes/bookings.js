const router = require('express').Router();
const { Asset, Booking, Review, User } = require('../models');
const { requireAuth } = require('../middleware/auth');
const upload = require('../middleware/upload');
const { dayDiff, token, ACTIVE, recalcTrust } = require('../utils');

const COUPONS = { SHAREHUB10: 0.1, WELCOME: 0.05 };

async function isFree(asset, start, end) {
  const clash = await Booking.exists({ asset: asset._id, status: { $in: ACTIVE }, startDate: { $lt: end }, endDate: { $gt: start } });
  const blocked = asset.blockedRanges.some(r => r.from < end && r.to > start);
  return !clash && !blocked;
}
function price(asset, start, end, coupon) {
  const days = dayDiff(start, end);
  const rentalFee = days * asset.pricePerDay;
  const discount = Math.round(rentalFee * (COUPONS[(coupon || '').toUpperCase()] || 0));
  return { days, rentalFee, deposit: asset.deposit, discount, total: rentalFee - discount + asset.deposit };
}

/* ===== TEMPORARY CART (Session) – Chương VIII =====
   Khách chưa đăng nhập vẫn lưu được "đơn nháp" trong req.session (RAM/store phía server).
   Khi đăng nhập + thanh toán → ghi vĩnh viễn vào MongoDB. */
router.get('/draft', async (req, res) => {
  const d = req.session.draft;
  if (!d) return res.json(null);
  if (Date.now() > d.expiresAt) { delete req.session.draft; return res.json(null); }
  const asset = await Asset.findById(d.assetId).populate('owner', 'name avatar');
  res.json({ ...d, asset, ...price(asset, new Date(d.startDate), new Date(d.endDate), d.coupon) });
});
router.post('/draft', async (req, res) => {
  const { assetId, startDate, endDate, coupon } = req.body;
  const asset = await Asset.findById(assetId);
  if (!asset || !startDate || !endDate || new Date(endDate) <= new Date(startDate)) return res.status(400).json({ message: 'Invalid rental period.' });
  if (!(await isFree(asset, new Date(startDate), new Date(endDate)))) return res.status(409).json({ message: 'Those dates are no longer available.' });
  req.session.draft = { assetId, startDate, endDate, coupon: coupon || '', expiresAt: Date.now() + 15 * 60 * 1000 }; // giữ chỗ 15 phút
  res.json({ ok: true, expiresAt: req.session.draft.expiresAt });
});
router.delete('/draft', (req, res) => { delete req.session.draft; res.json({ ok: true }); });

// Thanh toán + tạo đơn (đồng bộ vĩnh viễn từ Session → MongoDB)
router.post('/checkout', requireAuth, async (req, res) => {
  const d = req.session.draft;
  if (!d || Date.now() > d.expiresAt) return res.status(410).json({ message: 'Your 15-minute hold has expired. Please select dates again.' });
  const asset = await Asset.findById(d.assetId);
  if (String(asset.owner) === String(req.user._id)) return res.status(400).json({ message: 'You cannot rent your own item.' });
  const start = new Date(d.startDate), end = new Date(d.endDate);
  if (!(await isFree(asset, start, end))) return res.status(409).json({ message: 'Those dates are no longer available.' });
  const p = price(asset, start, end, d.coupon);
  const method = req.body.paymentMethod || 'wallet';
  if (method === 'wallet') {
    if (req.user.walletBalance < p.total) return res.status(402).json({ message: 'Insufficient wallet balance.' });
    req.user.walletBalance -= p.total; await req.user.save();
  }
  const booking = await Booking.create({
    asset: asset._id, renter: req.user._id, owner: asset.owner, startDate: start, endDate: end, ...p,
    handoverAddress: asset.location?.address, paymentMethod: method, paymentStatus: 'authorized', status: 'pending',
    pickupToken: token(), returnToken: token(),
  });
  delete req.session.draft;
  res.status(201).json(booking);
});

router.get('/', requireAuth, async (req, res) => {
  const role = req.query.role === 'owner' ? 'owner' : 'renter';
  const list = await Booking.find({ [role]: req.user._id }).sort('-createdAt')
    .populate('asset', 'title images category location').populate('renter owner', 'name avatar trustScore');
  res.json(list);
});

router.get('/:id', requireAuth, async (req, res) => {
  const b = await Booking.findById(req.params.id).populate('asset').populate('renter owner', 'name avatar trustScore ratingAvg phone');
  if (!b) return res.status(404).json({ message: 'Booking not found.' });
  const uid = String(req.user._id);
  if (![String(b.renter._id), String(b.owner._id)].includes(uid) && req.user.role !== 'admin') return res.status(403).json({ message: 'Forbidden.' });
  const obj = b.toObject();
  const isRenter = uid === String(b.renter._id);
  // Mỗi bên chỉ thấy mã QR mình cần hiển thị
  if (isRenter) delete obj.pickupToken; else if (req.user.role !== 'admin') delete obj.returnToken;
  obj.myRole = isRenter ? 'renter' : (uid === String(b.owner._id) ? 'owner' : 'admin');
  res.json(obj);
});

async function loadMine(req, res, role) {
  const b = await Booking.findById(req.params.id);
  if (!b || String(b[role]) !== String(req.user._id)) { res.status(403).json({ message: 'Forbidden.' }); return null; }
  return b;
}

// Chủ đồ chấp nhận / từ chối → khi chấp nhận, tiền được "capture" (đã thanh toán, cọc bị giữ)
router.post('/:id/approve', requireAuth, async (req, res) => {
  const b = await loadMine(req, res, 'owner'); if (!b) return;
  if (b.status !== 'pending') return res.status(400).json({ message: 'Booking is not pending.' });
  b.status = 'paid'; b.paymentStatus = 'captured'; await b.save(); res.json(b);
});
router.post('/:id/reject', requireAuth, async (req, res) => {
  const b = await loadMine(req, res, 'owner'); if (!b) return;
  if (b.status !== 'pending') return res.status(400).json({ message: 'Booking is not pending.' });
  b.status = 'rejected'; b.rejectReason = req.body.reason || 'No reason given';
  b.paymentStatus = 'refunded';
  await User.updateOne({ _id: b.renter }, { $inc: { walletBalance: b.total } });
  await b.save(); res.json(b);
});
router.post('/:id/cancel', requireAuth, async (req, res) => {
  const b = await loadMine(req, res, 'renter'); if (!b) return;
  if (!['pending', 'paid'].includes(b.status)) return res.status(400).json({ message: 'Cannot cancel now.' });
  b.status = 'cancelled'; b.paymentStatus = 'refunded';
  await User.updateOne({ _id: b.renter }, { $inc: { walletBalance: b.total } });
  await b.save(); res.json(b);
});

// CHECK-IN: người thuê quét QR của chủ (nhập/mở token) + chụp tối đa 4 ảnh hiện trạng
router.post('/:id/checkin', requireAuth, upload.array('photos', 4), async (req, res) => {
  const b = await loadMine(req, res, 'renter'); if (!b) return;
  if (b.status !== 'paid') return res.status(400).json({ message: 'Booking must be paid/approved first.' });
  if ((req.body.token || '').toUpperCase() !== b.pickupToken) return res.status(400).json({ message: 'Invalid QR code.' });
  b.checkinPhotos = (req.files || []).map(f => '/uploads/' + f.filename);
  b.checkinAt = new Date(); b.status = 'picked_up'; await b.save(); res.json(b);
});
// CHECK-OUT: chủ quét QR của người thuê + chụp ảnh đối chiếu
router.post('/:id/checkout', requireAuth, upload.array('photos', 4), async (req, res) => {
  const b = await loadMine(req, res, 'owner'); if (!b) return;
  if (b.status !== 'picked_up') return res.status(400).json({ message: 'Item has not been picked up.' });
  if ((req.body.token || '').toUpperCase() !== b.returnToken) return res.status(400).json({ message: 'Invalid QR code.' });
  b.checkoutPhotos = (req.files || []).map(f => '/uploads/' + f.filename);
  b.checkoutAt = new Date(); b.status = 'returned'; await b.save(); res.json(b);
});
// Chủ xác nhận không có vấn đề → hoàn cọc, hoàn tất
router.post('/:id/complete', requireAuth, async (req, res) => {
  const b = await loadMine(req, res, 'owner'); if (!b) return;
  if (b.status !== 'returned') return res.status(400).json({ message: 'Item has not been returned.' });
  await User.updateOne({ _id: b.renter }, { $inc: { walletBalance: b.deposit, completedCount: 1 } });
  await User.updateOne({ _id: b.owner }, { $inc: { walletBalance: b.rentalFee - b.discount, completedCount: 1 } });
  b.status = 'completed'; b.paymentStatus = 'refunded'; await b.save();
  await Promise.all([recalcTrust(b.renter), recalcTrust(b.owner)]);
  res.json(b);
});
// Báo cáo sự cố / khiếu nại
router.post('/:id/dispute', requireAuth, async (req, res) => {
  const b = await Booking.findById(req.params.id);
  const uid = String(req.user._id);
  if (!b || ![String(b.renter), String(b.owner)].includes(uid)) return res.status(403).json({ message: 'Forbidden.' });
  if (!['picked_up', 'returned'].includes(b.status)) return res.status(400).json({ message: 'Dispute is only possible after pickup.' });
  b.status = 'disputed'; b.dispute = { openedBy: req.user._id, reason: req.body.reason || 'Issue reported', status: 'open' };
  await b.save(); res.json(b);
});

// Đánh giá chéo (mutual review)
router.post('/:id/review', requireAuth, async (req, res) => {
  const b = await Booking.findById(req.params.id);
  const uid = String(req.user._id);
  if (!b || b.status !== 'completed' || ![String(b.renter), String(b.owner)].includes(uid)) return res.status(400).json({ message: 'Cannot review this booking.' });
  const isRenter = uid === String(b.renter);
  if (isRenter ? b.reviewedByRenter : b.reviewedByOwner) return res.status(400).json({ message: 'Already reviewed.' });
  const to = isRenter ? b.owner : b.renter;
  const rating = Math.min(5, Math.max(1, +req.body.rating || 5));
  await Review.create({ booking: b._id, asset: b.asset, from: req.user._id, to, rating, comment: req.body.comment });
  const target = await User.findById(to);
  target.ratingAvg = +(((target.ratingAvg * target.ratingCount) + rating) / (target.ratingCount + 1)).toFixed(2);
  target.ratingCount += 1; await target.save();
  if (isRenter) {
    const a = await Asset.findById(b.asset);
    a.ratingAvg = +(((a.ratingAvg * a.ratingCount) + rating) / (a.ratingCount + 1)).toFixed(2); a.ratingCount += 1; await a.save();
    b.reviewedByRenter = true;
  } else b.reviewedByOwner = true;
  await b.save(); await recalcTrust(to);
  res.json({ ok: true });
});

module.exports = router;
