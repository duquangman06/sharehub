import { Component, inject, OnInit, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ApiService, CatalogService, ToastService, money } from '../../core/services';

@Component({
  standalone: true, imports: [FormsModule],
  template: `<div class="grid g2" style="align-items:start">
    <div class="col">
      <div class="card"><h3>Listings awaiting approval</h3>@for (a of assets(); track a._id) {
        <div class="row between" style="padding:8px 0;border-bottom:1px solid var(--line)"><div><b>{{ a.title }}</b><div class="small mut">{{ a.owner?.name }} · {{ money(a.pricePerDay) }}/day</div></div>
          <div class="row"><button class="btn sm" (click)="assetAct(a, 'approve')">Approve</button><button class="btn danger sm" (click)="assetAct(a, 'reject')">Reject</button></div></div>
      } @empty { <div class="empty">Nothing to moderate.</div> }</div>
      <div class="card"><h3>Identity verification (CCCD / passport)</h3>@for (u of kyc(); track u._id) {
        <div style="padding:8px 0;border-bottom:1px solid var(--line)"><b>{{ u.name }}</b> <span class="small mut">{{ u.email }}</span>
          <div class="row" style="margin:6px 0">@for (i of u.kycImages; track i) { <a [href]="i" target="_blank"><img [src]="i" style="width:110px;height:72px;object-fit:cover;border-radius:8px"></a> }</div>
          <div class="row"><button class="btn sm" (click)="kycAct(u, 'approve')">Approve</button><button class="btn danger sm" (click)="kycAct(u, 'reject')">Reject</button></div></div>
      } @empty { <div class="empty">No pending verifications.</div> }</div>
    </div>
    <div class="card"><h3>Categories</h3>
      <div class="row mb"><input [(ngModel)]="icon" style="width:70px" placeholder="📦"><input [(ngModel)]="name" placeholder="New category"><button class="btn sm" [disabled]="!name" (click)="add()">Add</button></div>
      @for (c of cat.categories(); track c._id) { <div class="row between" style="padding:6px 0"><span>{{ c.icon }} {{ c.name }}</span><button class="btn ghost sm" (click)="rm(c._id)">Delete</button></div> }</div>
  </div>`,
})
export class AdminModerationComponent implements OnInit {
  private api = inject(ApiService); private toast = inject(ToastService); cat = inject(CatalogService); money = money;
  assets = signal<any[]>([]); kyc = signal<any[]>([]); name = ''; icon = '📦';
  ngOnInit() { this.load(); }
  load() { this.api.get<any[]>('/api/admin/assets').subscribe(a => this.assets.set(a)); this.api.get<any[]>('/api/admin/kyc').subscribe(k => this.kyc.set(k)); }
  assetAct(a: any, act: string) { this.api.post(`/api/admin/assets/${a._id}/${act}`).subscribe(() => { this.toast.show('Done.'); this.load(); }); }
  kycAct(u: any, act: string) { this.api.post(`/api/admin/kyc/${u._id}/${act}`).subscribe(() => { this.toast.show('Done.'); this.load(); }); }
  add() { this.api.post('/api/admin/categories', { name: this.name, icon: this.icon }).subscribe(() => { this.name = ''; this.cat.loadCategories(); }); }
  rm(id: string) { this.api.del('/api/admin/categories/' + id).subscribe(() => this.cat.loadCategories()); }
}
